
package test;

import model.Pays;

/**
 *
 *
 */
public class Test {
    public static void main(String[] args) {
        Pays p = new Pays();
        System.out.println(p.getLesDeps());
        System.out.println(p.getLesSpes());
        System.out.println("hello");
    }
}